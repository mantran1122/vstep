/* global React, ReactDOM, useTweaks, TweaksPanel, TweakSection, TweakSlider */
const { useState, useEffect, useRef, useMemo, useCallback } = React;

/* ────────────────────────────────────────────────────────────────────────
   Project data — fictional Vietnamese exhibition booths
   Colors are deep dyed-fabric tones that sit well on warm paper-yellow.
   ──────────────────────────────────────────────────────────────────────── */
const PROJECTS = [
  { id: 1, name: "Triển lãm Du thuyền Quốc tế", tags: ["Hàng hải", "B2C"],          size: "480m²", year: "2024", venue: "SECC, TP.HCM",      color: "#B23E2C", swatch: "vermillion" },
  { id: 2, name: "Hội chợ Thú cưng Việt Nam",   tags: ["Thú cưng", "Lifestyle"],     size: "240m²", year: "2024", venue: "ICE Hà Nội",        color: "#2E4A3B", swatch: "matcha" },
  { id: 3, name: "Vietnam Motor Show",          tags: ["Ô tô", "Premium"],           size: "720m²", year: "2024", venue: "SECC, TP.HCM",      color: "#1A2238", swatch: "sumi" },
  { id: 4, name: "Vietbeauty & Cosmobeauté",    tags: ["Mỹ phẩm", "B2B"],            size: "360m²", year: "2024", venue: "SECC, TP.HCM",      color: "#6B4226", swatch: "umber" },
  { id: 5, name: "Vietnam Foodexpo",            tags: ["F&B", "Xuất khẩu"],          size: "540m²", year: "2024", venue: "SECC, TP.HCM",      color: "#1F3A5F", swatch: "ai" },
  { id: 6, name: "Triển lãm Nội thất VIFA",     tags: ["Nội thất", "Design"],        size: "420m²", year: "2024", venue: "SECC, TP.HCM",      color: "#8C3F2A", swatch: "terracotta" },
  { id: 7, name: "Hội nghị Công nghệ Sài Gòn",  tags: ["Công nghệ", "Conference"],   size: "260m²", year: "2024", venue: "GEM Center",        color: "#1A1814", swatch: "ink" },
  { id: 8, name: "Comic Market Hà Nội",         tags: ["Văn hóa", "Pop-up"],         size: "300m²", year: "2024", venue: "ICE Hà Nội",        color: "#3C2A5C", swatch: "tsurubami" },
];

const N = PROJECTS.length;

/* ────────────────────────────────────────────────────────────────────────
   Helpers
   ──────────────────────────────────────────────────────────────────────── */
const TAU = Math.PI * 2;
const HALF = Math.PI;
// normalize an angle to (-π, π]
function norm(a) {
  let x = ((a + HALF) % TAU + TAU) % TAU - HALF;
  return x;
}
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pad2 = (n) => String(n).padStart(2, "0");

/* ────────────────────────────────────────────────────────────────────────
   The curved drag-spin carousel
   ──────────────────────────────────────────────────────────────────────── */
function Carousel({ rotation, onDragStart, onDragMove, onDragEnd, onWheel, onCardClick, curveDepth, cardScale }) {
  const VIS = Math.PI * 0.66;       // visible front-arc half-angle
  const ARCH_RX = 520;              // horizontal radius of arch in px (will scale w/ container)
  const ARCH_W_SCALE = 1.0;         // tuned per container width below
  const stepAngle = TAU / N;

  const containerRef = useRef(null);
  const [width, setWidth] = useState(1200);

  // measure container
  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) setWidth(e.contentRect.width);
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  // map width to arch radius (clamped)
  const archRx = clamp(width * 0.42, 320, 720);

  // build visible items
  const items = useMemo(() => {
    return PROJECTS.map((p, i) => {
      const theta = norm(i * stepAngle + rotation);
      // scaled to ±π/2 for visible window
      const phi = (theta / VIS) * (Math.PI / 2);
      const visible = Math.abs(theta) <= VIS;
      const cos = Math.cos(phi);
      const sin = Math.sin(phi);
      const x = sin * archRx;
      const y = -cos * curveDepth;          // negative = up on screen → peak at center
      const scale = (0.55 + 0.45 * cos) * cardScale;
      const opacity = visible ? Math.max(0, Math.pow(cos, 0.55)) : 0;
      // z-index: center is on top
      const z = Math.round(cos * 100);
      return { p, theta, phi, x, y, scale, opacity, z, visible, index: i };
    });
  }, [rotation, archRx, curveDepth, cardScale]);

  // index of "front" card (closest to θ=0)
  const frontIdx = useMemo(() => {
    let best = 0, bestAbs = Infinity;
    for (const it of items) {
      const a = Math.abs(it.theta);
      if (a < bestAbs) { bestAbs = a; best = it.index; }
    }
    return best;
  }, [items]);

  /* pointer drag handling — local pass-through so the consumer
     keeps a single source of truth for rotation/velocity */
  const handleDown = (e) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    onDragStart(e.clientX, performance.now());
  };
  const handleMove = (e) => onDragMove(e.clientX, performance.now());
  const handleUp = (e) => {
    try { e.currentTarget.releasePointerCapture(e.pointerId); } catch (_) {}
    onDragEnd();
  };

  return (
    <div className="carousel-shell">
      {/* faint arc guideline */}
      <svg className="arch-guide" viewBox="-600 -240 1200 360" preserveAspectRatio="none" aria-hidden="true">
        <path d={`M ${-archRx} 0 Q 0 ${-curveDepth * 2} ${archRx} 0`} stroke="rgba(26,24,20,0.14)" strokeWidth="0.6" fill="none" strokeDasharray="2 6" />
        {/* registration ticks */}
        {Array.from({ length: 9 }).map((_, i) => {
          const t = (i / 8) - 0.5;
          const a = t * Math.PI;
          const cx = Math.sin(a) * archRx;
          const cy = -Math.cos(a) * curveDepth;
          return <circle key={i} cx={cx} cy={cy} r="1.1" fill="rgba(26,24,20,0.35)" />;
        })}
      </svg>

      <div
        ref={containerRef}
        className="carousel"
        onPointerDown={handleDown}
        onPointerMove={handleMove}
        onPointerUp={handleUp}
        onPointerCancel={handleUp}
        onWheel={onWheel}
      >
        {items.map((it) => (
          <Card
            key={it.p.id}
            item={it}
            isFront={it.index === frontIdx}
            onClick={() => onCardClick(it.index)}
          />
        ))}
      </div>

      <FrontMeta project={PROJECTS[frontIdx]} frontIdx={frontIdx} />
    </div>
  );
}

/* ────────────────────────────────────────────────────────────────────────
   A single card on the wheel
   ──────────────────────────────────────────────────────────────────────── */
function Card({ item, isFront, onClick }) {
  const { p, x, y, scale, opacity, z, visible } = item;
  if (!visible) return null;

  // tiny parallax inside the card for the colored field
  const tilt = clamp(item.phi * -10, -8, 8);
  const dragStartRef = useRef({ x: 0, y: 0, t: 0 });

  const onDown = (e) => {
    dragStartRef.current = { x: e.clientX, y: e.clientY, t: performance.now() };
  };
  const onUp = (e) => {
    const dx = Math.abs(e.clientX - dragStartRef.current.x);
    const dy = Math.abs(e.clientY - dragStartRef.current.y);
    const dt = performance.now() - dragStartRef.current.t;
    // treat as a click only if pointer barely moved & was quick
    if (dx < 6 && dy < 6 && dt < 400 && !isFront) {
      e.stopPropagation();
      onClick && onClick();
    }
  };

  return (
    <div
      className={"card" + (isFront ? " card--front" : "")}
      style={{
        transform: `translate3d(calc(-50% + ${x}px), calc(-50% + ${y}px), 0) scale(${scale})`,
        opacity,
        zIndex: 100 + z,
        cursor: isFront ? "grab" : "pointer",
      }}
      onPointerDown={onDown}
      onPointerUp={onUp}
    >
      <div className="card-frame">
        <div
          className="card-field"
          style={{
            background: p.color,
            transform: `rotateY(${tilt}deg)`,
          }}
        >
          {/* graphic surface — abstract booth massing */}
          <BoothGlyph color={p.color} swatch={p.swatch} />

          {/* overlay label */}
          <div className="card-overlay">
            <div className="card-num">N°{pad2(p.id)}</div>
            <div className="card-name">{p.name}</div>
          </div>

          {/* corner ticks (registration) */}
          <span className="tick tl"></span>
          <span className="tick tr"></span>
          <span className="tick bl"></span>
          <span className="tick br"></span>
        </div>
        {/* caption under card */}
        <div className="card-caption">
          <span className="cap-tag">{p.tags[0]}</span>
          <span className="cap-dot">·</span>
          <span className="cap-size">{p.size}</span>
        </div>
      </div>
    </div>
  );
}

/* abstract booth-massing glyph rendered as overlaid bars/blocks so each
   card reads as a unique booth layout silhouette without us pretending to
   illustrate a real photo. */
function BoothGlyph({ color, swatch }) {
  // pre-baked compositions per swatch
  const layouts = {
    vermillion: [{x: 14, y: 60, w: 28, h: 22}, {x: 44, y: 48, w: 30, h: 34}, {x: 76, y: 64, w: 12, h: 18}],
    matcha:     [{x: 10, y: 56, w: 22, h: 26}, {x: 36, y: 38, w: 14, h: 44}, {x: 54, y: 52, w: 32, h: 30}],
    sumi:       [{x: 8,  y: 52, w: 36, h: 30}, {x: 50, y: 30, w: 24, h: 52}, {x: 78, y: 64, w: 12, h: 18}],
    umber:      [{x: 12, y: 60, w: 18, h: 22}, {x: 34, y: 44, w: 32, h: 38}, {x: 70, y: 56, w: 20, h: 26}],
    ai:         [{x: 8,  y: 48, w: 26, h: 34}, {x: 38, y: 38, w: 20, h: 44}, {x: 62, y: 56, w: 30, h: 26}],
    terracotta: [{x: 10, y: 62, w: 14, h: 20}, {x: 28, y: 40, w: 38, h: 42}, {x: 70, y: 54, w: 22, h: 28}],
    ink:        [{x: 6,  y: 50, w: 40, h: 32}, {x: 52, y: 34, w: 16, h: 48}, {x: 72, y: 58, w: 20, h: 24}],
    tsurubami:  [{x: 12, y: 56, w: 22, h: 26}, {x: 40, y: 36, w: 18, h: 46}, {x: 64, y: 50, w: 28, h: 32}],
  };
  const bars = layouts[swatch] || layouts.vermillion;

  return (
    <svg className="glyph" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
      {/* floor line */}
      <line x1="0" y1="82" x2="100" y2="82" stroke="rgba(255,255,255,0.22)" strokeWidth="0.4" />
      {/* booths */}
      {bars.map((b, i) => (
        <g key={i}>
          <rect x={b.x} y={b.y} width={b.w} height={b.h} fill="rgba(255,255,255,0.07)" />
          <rect x={b.x} y={b.y} width={b.w} height="1.2" fill="rgba(255,255,255,0.35)" />
          {/* roof tick */}
          <line x1={b.x + 2} y1={b.y - 2} x2={b.x + b.w - 2} y2={b.y - 2} stroke="rgba(255,255,255,0.18)" strokeWidth="0.3" />
        </g>
      ))}
      {/* faint horizon ticks */}
      {Array.from({ length: 20 }).map((_, i) => (
        <line key={i} x1={i * 5} y1="84" x2={i * 5} y2="86" stroke="rgba(255,255,255,0.15)" strokeWidth="0.3" />
      ))}
    </svg>
  );
}

/* Front card's info shown below carousel */
function FrontMeta({ project, frontIdx }) {
  return (
    <div className="front-meta">
      <div className="fm-row">
        <span className="fm-idx">{pad2(frontIdx + 1)} / {pad2(N)}</span>
        <span className="fm-rule" />
        <span className="fm-tags">
          {project.tags.map((t, i) => (
            <span key={i} className="fm-tag">{t}</span>
          ))}
        </span>
        <span className="fm-rule" />
        <span className="fm-size">{project.size}</span>
        <span className="fm-rule" />
        <span className="fm-venue">{project.venue} · {project.year}</span>
      </div>
      <div className="fm-name">{project.name}</div>
    </div>
  );
}

/* ────────────────────────────────────────────────────────────────────────
   Page header
   ──────────────────────────────────────────────────────────────────────── */
function Header() {
  return (
    <header className="page-head">
      <div className="head-row">
        <div className="head-left">
          <span className="dot" /> 
          <span className="mono">BOX&nbsp;·&nbsp;SAIGON&nbsp;2024</span>
        </div>
        <div className="head-right mono">
          <span>10°46′N&nbsp;106°41′E</span>
          <span className="sep">/</span>
          <span>WORKS&nbsp;.04</span>
        </div>
      </div>

      <div className="title-block">
        <div className="eyebrow">
          <span className="kanji">施工実績</span>
          <span className="eyebrow-rule" />
          <span className="eyebrow-en">Works · Dự án đã thực hiện</span>
        </div>
        <h1 className="display">
          Những gian hàng <em>chúng tôi</em>
          <br />
          đã dựng nên.
        </h1>
        <p className="lede">
          Kéo bánh xe để đi vòng quanh khu triển lãm — từng booth lần lượt hiện ra như một trạm dừng nhỏ trên hành trình tám năm dựng cảnh.
        </p>
      </div>
    </header>
  );
}

/* ────────────────────────────────────────────────────────────────────────
   Tweakable defaults
   ──────────────────────────────────────────────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "curveDepth": 110,
  "autoSpeed": 6,
  "cardSize": 1.0
}/*EDITMODE-END*/;

/* ────────────────────────────────────────────────────────────────────────
   Root
   ──────────────────────────────────────────────────────────────────────── */
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [rotation, setRotation] = useState(-Math.PI / N); // start with no card exactly center
  const rotationRef = useRef(-Math.PI / N);
  const dragRef = useRef({ active: false, startX: 0, startRot: 0, lastX: 0, lastT: 0 });
  const velRef = useRef(0);
  const autoSpeedRef = useRef(t.autoSpeed);
  autoSpeedRef.current = t.autoSpeed;
  const interactedRef = useRef(false);

  // glide target — when set, animation loop eases rotation toward it
  const targetRef = useRef(null);

  const updateRotation = useCallback((updater) => {
    setRotation(r => {
      const next = typeof updater === "function" ? updater(r) : updater;
      rotationRef.current = next;
      return next;
    });
  }, []);

  /* animation loop: inertia decay + glide-to-target + optional auto-drift */
  useEffect(() => {
    let raf;
    let last = performance.now();
    const tick = (now) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      if (!dragRef.current.active) {
        updateRotation(r => {
          let next = r;

          // glide toward target (overrides inertia + auto)
          if (targetRef.current != null) {
            const diff = targetRef.current - r;
            if (Math.abs(diff) < 0.0015) {
              next = targetRef.current;
              targetRef.current = null;
              velRef.current = 0;
            } else {
              // critically-damped-ish approach
              next = r + diff * Math.min(1, dt * 9);
              velRef.current = 0;
            }
            return next;
          }

          // inertia
          if (Math.abs(velRef.current) > 0.0005) {
            next += velRef.current * dt;
            velRef.current *= Math.pow(0.0008, dt);
            if (Math.abs(velRef.current) < 0.0005) velRef.current = 0;
          }
          // auto-drift
          const auto = autoSpeedRef.current / 100;
          if (auto > 0 && Math.abs(velRef.current) < 0.05) {
            next += auto * dt;
          }
          return next;
        });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [updateRotation]);

  const onDragStart = useCallback((x, time) => {
    dragRef.current = { active: true, startX: x, startRot: rotationRef.current, lastX: x, lastT: time };
    velRef.current = 0;
    targetRef.current = null;
    interactedRef.current = true;
    document.body.style.cursor = "grabbing";
  }, []);

  const onDragMove = useCallback((x, time) => {
    if (!dragRef.current.active) return;
    const dx = x - dragRef.current.startX;
    const next = dragRef.current.startRot + dx * 0.0035;
    const dtLocal = Math.max(0.001, (time - dragRef.current.lastT) / 1000);
    const dxLocal = x - dragRef.current.lastX;
    velRef.current = (dxLocal * 0.0035) / dtLocal;
    dragRef.current.lastX = x;
    dragRef.current.lastT = time;
    updateRotation(next);
  }, [updateRotation]);

  const onDragEnd = useCallback(() => {
    dragRef.current.active = false;
    document.body.style.cursor = "";
  }, []);

  // wheel / trackpad → spin
  const onWheel = useCallback((e) => {
    // horizontal scroll preferred, otherwise vertical
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    if (delta === 0) return;
    e.preventDefault();
    interactedRef.current = true;
    targetRef.current = null;
    velRef.current = 0;
    updateRotation(r => r + delta * 0.003);
  }, [updateRotation]);

  // click a side card → glide it to center (front)
  const onCardClick = useCallback((index) => {
    interactedRef.current = true;
    const stepAngle = TAU / N;
    // current angle of clicked card = i * step + rotation, normalized
    const current = norm(index * stepAngle + rotationRef.current);
    // we want this card's angle to become 0 → rotation_new = rotation - current
    // but choose the shortest path
    targetRef.current = rotationRef.current - current;
  }, []);

  // keyboard ← → → step one card
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      interactedRef.current = true;
      const stepAngle = TAU / N;
      const dir = e.key === "ArrowLeft" ? +1 : -1;
      const base = targetRef.current ?? rotationRef.current;
      // snap base to nearest step, then add one step
      const snapped = Math.round(base / stepAngle) * stepAngle;
      targetRef.current = snapped + dir * stepAngle;
      velRef.current = 0;
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <div className="page">
        <Header />
        <Carousel
          rotation={rotation}
          onDragStart={onDragStart}
          onDragMove={onDragMove}
          onDragEnd={onDragEnd}
          onWheel={onWheel}
          onCardClick={onCardClick}
          curveDepth={t.curveDepth}
          cardScale={t.cardSize}
        />
        <Footer interacted={interactedRef.current} />
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Carousel">
          <TweakSlider
            label="Curve depth"
            value={t.curveDepth}
            min={0} max={220} step={2}
            onChange={(v) => setTweak("curveDepth", v)}
            unit="px"
            help="0 = phẳng, 220 = vòm cao"
          />
          <TweakSlider
            label="Auto-rotate speed"
            value={t.autoSpeed}
            min={0} max={30} step={1}
            onChange={(v) => setTweak("autoSpeed", v)}
            help="0 = đứng yên, 30 = trôi nhanh"
          />
          <TweakSlider
            label="Card size"
            value={t.cardSize}
            min={0.7} max={1.3} step={0.05}
            onChange={(v) => setTweak("cardSize", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

function Footer({ interacted }) {
  return (
    <footer className="page-foot">
      <div className="hint">
        <span className="arrow">←</span>
        <span>{interacted ? "kéo · cuộn · click · phím mũi tên" : "kéo, cuộn, hoặc click để đi vòng"}</span>
        <span className="arrow">→</span>
      </div>
      <div className="foot-meta mono">
        <span>BOX&nbsp;CO.&nbsp;LTD</span>
        <span className="sep">—</span>
        <span>EST.&nbsp;2016</span>
      </div>
    </footer>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
